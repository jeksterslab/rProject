library(testthat)
library(rProject)

test_check("rProject")
